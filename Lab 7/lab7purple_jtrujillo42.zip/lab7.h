//contains all the #includes for the c++ libraries, global constants, and function prototypes

#ifndef LAB7_H
#define LAB7_H

#include <iostream>
using namespace std;

void getData(string&, string&, int&, int&, string&, string&);
bool calculateResults(string, string, int, int, string, string);

#endif