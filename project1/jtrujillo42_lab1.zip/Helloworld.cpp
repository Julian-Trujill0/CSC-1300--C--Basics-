#include <iostream>
using namespace std;
int main ()
{
    cout << "Hello World!";
    cout << endl;
    return 0;
}
